public enum TetLConfiguration {

    UP,
    DOWN,
    RIGHT,
    LEFT

}
