public enum TetTConfiguration {
    DOWN,
    UP,
    RIGHT,
    LEFT
}
