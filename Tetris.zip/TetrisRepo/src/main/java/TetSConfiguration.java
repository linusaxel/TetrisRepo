public enum TetSConfiguration {

    HORIZONTAL,
    VERTICAL,
}
