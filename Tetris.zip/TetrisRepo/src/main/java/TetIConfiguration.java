public enum TetIConfiguration {

    VERTICAL,
    HORIZONTAL

}
